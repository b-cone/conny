	<? include "head.php"; ?>

	<div id="banner"><img src="./images/main_04.jpg" alt="" width="100%" height="100%"></div>


	<div id="cs_bg">
		<div id="cs"><img src="./images/main_06.jpg" alt=""></div>
	</div>
	<div id="icon_bg">
		<div id="icon"><img src="./images/main_09.jpg" alt=""></div>
	</div>

    <? include "footer.php"; ?>
