

<div id="footer_bg">
    <div id="footer"><img src="./images/map_18.jpg" alt=""></div>
</div>

</body>
</html>