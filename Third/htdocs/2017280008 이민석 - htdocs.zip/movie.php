<? include "head.php"; ?>

<div id="smlbn"><img src="./images/biz_10.jpg" alt="" width="100%" height="100%"></div>
<div id="mov_bg">
    <div id="movnav"><img src="./images/movie_08.jpg" alt=""><img src="./images/movie_09.jpg" alt=""><img src="./images/movie_10.jpg" alt=""><img src="./images/movie_11.jpg" alt=""></div>
</div>
<div id="movtitle"><img src="./images/movie_14.jpg" alt=""></div>
<div id="video"><img src="./images/movie_16.jpg" alt=""></div>





<? include "footer.php"; ?>