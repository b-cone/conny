<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>구로역 엔트리움 _ 2017280008 이민석</title>

    <style type= "text/css">
        body{ padding: 0; margin: 0;}
        #header{width: 1164px; height: 85px; margin: 0 auto;}
        #banner{width: 100%; height: 738px; margin: 0 auto;}

        #cs_bg{width: 100%; height: 212px; background: url(./images/main_08.jpg)}
            #cs{width: 1164px; height: 212px; margin: 0 auto;}
        #icon_bg{width: 100%; height: 254px; background: url(./images/main_08.jpg)}
            #icon{width: 1164px; height: 254px; margin: 0 auto;}

        #smlbn{width: 100%; height: 213px; margin: 0 auto;}
        #biz_bg{width: 100%; height: 59px; background: url(./images/biz_11.jpg)}
            #biznav{width: 1164px; height: 59px; margin: 0 auto;}
        #biztitle{width: 1164px; height: 205px; margin: 0 auto;}
        #bizmain{width: 1164px; height: 1257px; margin: 0 auto;}

        #map_bg{width: 100%; height: 59px; background: url(./images/biz_11.jpg)}
            #mapnav{width: 1164px; height: 59px; margin: 0 auto;}
        #maptitle{width: 1164px; height: 205px; margin: 0 auto;}
        #map{width: 1164px; height: 764px; margin: 0 auto;}

        #mov_bg{width: 100%; height: 59px; background: url(./images/biz_11.jpg)}
            #movnav{width: 1164px; height: 59px; margin: 0 auto;}
        #movtitle{width: 1164px; height: 205px; margin: 0 auto;}
        #video{width: 1164px; height: 810px; margin: 0 auto;}
        
        #footer_bg{width: 100%; height: 117px; background: url(./images/map_17.jpg)}
            #footer{width: 1164px; height: 117px; margin: 0 auto;}

    </style>


</head>
<body>


    <div id="header"><a href="index.php"><img src="./images/biz_02.jpg" alt=""></a><a href="biz.php"><img src="./images/biz_03.jpg" alt=""></a><a href="movie.php"><img src="./images/biz_04.jpg" alt=""></a><img src="./images/biz_05.jpg" alt=""><img src="./images/biz_06.jpg" alt=""><a href="map.php"><img src="./images/biz_07.jpg" alt=""></a><img src="./images/biz_08.jpg" alt=""></div>


